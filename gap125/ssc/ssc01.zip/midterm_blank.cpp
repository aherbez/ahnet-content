#include <iostream>
#include <string>

using namespace std;

// this is the input for the keypad mission
int keypadInfo[9] = {9,6,0,2,0,0,0,0,4};

// this is the input for the "intercepted codename" mission
int paperScrap[5][11] = {{48,56,48,48,68,16,56,16,40,56,48},
	{40,16,40,40,68,40,16,40,40,32,40},
	{48,16,48,40,84,56,16,32,56,48,48},
	{40,16,40,40,84,40,16,40,40,32,40},
	{48,56,40,48,40,40,16,16,40,56,40}};

// input for bonus mission #2
int cityGrid[5][5] = {
	{0, 0, 0, 2, 1},
	{0, 1, 2, 0, 0},
	{3, 0, 5, 0, 7},
	{0, 2, 5, 1, 0},
	{0, 0, 2, 0, 1}};

// forward-declaration for test function
void testDevice();

string genPassword()
{
	// add code here to generate a randomized 16-character password
	// containing lowercase letters, uppercase letters, and numbers

	return "password";
}

// do not change the name of this function, as it will be called 
// by the testDevice function
bool deviceDuplicate(bool A, bool B, bool C, bool D)
{
	// add code here to return the correct output based on the 
	// details in the mission briefing

	return false;
}

void findKeyCode()
{
	// implement code here to get the keycode from keypadInfo

	cout << "OUTPUT THE KEYCODE HERE\n";
}

void decodeIntegersToText()
{
	// do something with the "paperScrap" variable here
	// print out the values as described in the mission documents
	// you should see a recognizable word as the output

	cout << "IMPLEMENT INTS TO TEXT\n";
}

// bonus mission #1
void findLocation(int north, int south, int east, int west)
{
	// examine the cityGrid data to find a location with the specified characteristics


	// output the answer as in the following line:
	cout << "FOUND LOCATION: (x,y) \n";
}

// bonus mission #2
void printEnvelopMessage()
{
	cout << "THE MESSAGE IS: \n";
}


// don't remove anything in here (adding code is fine)
int main()
{	
	// mission 1
	cout << "Passwords: \n";
	for (int i=0; i<5; i++)
	{
		cout << genPassword() << "\n";
	}

	// mission 2
	// this will call your deviceDuplicate() function with all possible inputs
	testDevice();

	// this function should solve mission 3
	findKeyCode();

	// this function should solve mission 4
	decodeIntegersToText();

	// bonus mission #1
	findLocation(1, 2, 5, 3);

	// bonus mission #2
	printEnvelopMessage();

	return 0;
}

void testDevice()
{

	cout << "TESTING DEVICE: \n";
	for (int i=0; i<16; i++)
	{
		bool A = ((i & 8) > 0);
		bool B = ((i & 4) > 0);
		bool C = ((i & 2) > 0);
		bool D = ((i & 1) > 0);

		bool result = deviceDuplicate(A, B, C, D);

		cout << A << " " << B << " " << C << " " << D << " " << result << "\n";


	}
}