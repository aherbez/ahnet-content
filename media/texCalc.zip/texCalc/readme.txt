texCalc.exe - Second Life Texture Calculator
version 1.2
author: J. Adrian Herbez
www.purplestatic.com
freely distributable, but please give credit

UPDATE 3/12/06: The program now offers a file browser dialog, allowing you to navigate to the desired image, rahter than typing the name


Second Life Texture Calculator

This program was written to make it easier to apply textures bit-by-bit in Linden Lab's Second Life online community. While SL allows users to upload custom textures and apply them on a face-by-face basis, it can sometimes be difficult to strike upon the proper settings for the UV repetitions and offsets. 

This script simplifies the process by allowing users to click and drag a selection region to identify a portion of a texture. The program then displays the UV repetition and offset settings necessary to have that portion of the texture fill the selected face. 

To use the program, download the zip and unpack it. Click on the "load texture" button, and use the ensuing dialog to navigate to the file you want (JPEG,Targa,GIF,or BMP). You should see the texture fill the main portion of the window. If nothing happens, the program couldn't find the specified file. Try re-typing the name. Note: if you want, you can also store your textures in a sub-folder within the installation directory. If you do, just be sure to type in the full pathname (relative to the exe) when loading images, such as images/myImage.bmp.

Once you have a file loaded, click and drag to specify the portion of the texture you're trying to use to see the UV repetitions and offsets appear. If you find that the guidelines and/or the highlighting are difficult to see due to the color makeup of your texture, change them by clicking in the color picker to set a color, then either the "guides" button (to set the guide line color) or the "dot" button (to set the color for the pointer-dot, as well as the highlighting).

This is version 1.2, so there may be unforseen issues. If the program isn't working and you're certain you've done everything right, feel free to send a *detailed* description of the problem to adrian@purplestatic.com. 

Happy texturing!

 