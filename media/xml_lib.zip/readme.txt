xml_Lib.mel
J. Adrian Herbez
www.purplestatic.com

xml_Lib.mel is a mel library designed to allow the user to work with XML data within Maya. The files contained in this ZIP are as follows:

readme.txt	this document
xml_lib.mel	the library itself
testGUI.mel	and example that uses xml_Lib.mel to load an XML file
books.xml	an example XML file- try using it with testGUI
docs.htm	documenation for the library
results.gif	an image used in docs.htm
XMLex.gif	an image used in docs.htm

Use of xml_Lib is free to anyone who wants it, but if you plan on reusing it and/or ditributing it with your own scripts, please give me credit and inclue a link to my site (www.purplestatic.com). Thanks!

Also, this is release 1.1, so there may be unforseen issues. If you think you've found a bug, please email a *specific* description of the issue to purplestatic@yahoo.com. 	
